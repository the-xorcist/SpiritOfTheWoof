using HarmonyLib;
using UnityEngine;

namespace SpiritOfTheWoof
{
    /// <summary>
    /// Main mod class - registers spell definitions.
    /// To add a new spell, add a new RegisterSpell call in RegisterAllSpells().
    /// </summary>
    public static class SpiritOfTheWoofMod
    {
        /// <summary>
        /// Register all custom Druid spells here.
        /// Called at plugin startup before databases are loaded.
        /// </summary>
        public static void RegisterAllSpells()
        {
            // Lesser Spirit of the Wolf - Entry level movement speed buff
            SpellRegistry.RegisterSpell(new SpellRegistry.SpellDefinition
            {
                Id = "spiritofthewoof_lesser_spirit_of_the_wolf",
                SpellName = "Lesser Spirit of the Wolf",
                Description = "Calls upon a lesser wolf spirit to increase movement speed.",
                IconFileName = "sow_64x64.png",
                Type = Spell.SpellType.Beneficial,
                Line = Spell.SpellLine.Global_Move,
                RequiredLevel = 5,
                ManaCost = 50,
                CastTime = 360f, // 6 seconds (60 ticks = 1 second)
                DurationTicks = 150, // 15 minutes (1 tick = 6 seconds)
                MovementSpeed = 1.5f,
                SelfOnly = false,
                SpellRange = 100f,
                ChargeFXIndex = 7,
                ResolveFXIndex = 7,
                StatusMessagePlayer = "You feel a lesser wolf spirit guiding your steps.",
                StatusMessageNPC = " feels a lesser wolf spirit.",
                GetClass = () => GameData.ClassDB?.Druid
            });

            // Spirit of the Wolf - Standard movement speed buff
            SpellRegistry.RegisterSpell(new SpellRegistry.SpellDefinition
            {
                Id = "spiritofthewoof_spirit_of_the_wolf",
                SpellName = "Spirit of the Wolf",
                Description = "Calls upon the spirit of the wolf to increase movement speed.",
                IconFileName = "sow_64x64.png",
                Type = Spell.SpellType.Beneficial,
                Line = Spell.SpellLine.Global_Move,
                RequiredLevel = 15,
                ManaCost = 100,
                CastTime = 600f, // 10 seconds (60 ticks = 1 second)
                DurationTicks = 300, // 30 minutes (1 tick = 6 seconds)
                MovementSpeed = 2.5f,
                SelfOnly = false,
                SpellRange = 100f,
                ChargeFXIndex = 7,
                ResolveFXIndex = 7,
                StatusMessagePlayer = "You feel the spirit of the wolf coursing through you.",
                StatusMessageNPC = " feels the spirit of the wolf.",
                GetClass = () => GameData.ClassDB?.Druid
            });

            // Spirit of the Greater Wolf - Enhanced movement speed buff
            SpellRegistry.RegisterSpell(new SpellRegistry.SpellDefinition
            {
                Id = "spiritofthewoof_spirit_of_the_greater_wolf",
                SpellName = "Spirit of the Greater Wolf",
                Description = "Calls upon a greater wolf spirit to greatly increase movement speed.",
                IconFileName = "sow_64x64.png",
                Type = Spell.SpellType.Beneficial,
                Line = Spell.SpellLine.Global_Move,
                RequiredLevel = 25,
                ManaCost = 150,
                CastTime = 600f, // 10 seconds (60 ticks = 1 second)
                DurationTicks = 450, // 45 minutes (1 tick = 6 seconds)
                MovementSpeed = 3.5f,
                SelfOnly = false,
                SpellRange = 100f,
                ChargeFXIndex = 7,
                ResolveFXIndex = 7,
                StatusMessagePlayer = "You feel a greater wolf spirit empowering your stride.",
                StatusMessageNPC = " feels a greater wolf spirit.",
                GetClass = () => GameData.ClassDB?.Druid
            });

            // Spirit of the Elder Wolf - Ultimate movement speed buff
            SpellRegistry.RegisterSpell(new SpellRegistry.SpellDefinition
            {
                Id = "spiritofthewoof_spirit_of_the_elder_wolf",
                SpellName = "Spirit of the Elder Wolf",
                Description = "Calls upon an ancient elder wolf spirit for maximum movement speed.",
                IconFileName = "sow_64x64.png",
                Type = Spell.SpellType.Beneficial,
                Line = Spell.SpellLine.Global_Move,
                RequiredLevel = 35,
                ManaCost = 200,
                CastTime = 300f, // 5 seconds (60 ticks = 1 second)
                DurationTicks = 600, // 60 minutes (1 tick = 6 seconds)
                MovementSpeed = 5.0f,
                SelfOnly = false,
                SpellRange = 100f,
                ChargeFXIndex = 7,
                ResolveFXIndex = 7,
                StatusMessagePlayer = "You feel an elder wolf spirit infusing your very being.",
                StatusMessageNPC = " feels an elder wolf spirit.",
                GetClass = () => GameData.ClassDB?.Druid
            });

            Debug.Log("SpiritOfTheWoofMod: All spell definitions registered.");
        }
    }

    /// <summary>
    /// Harmony patches to inject custom spells into the game's SpellDB.
    /// Spells are acquired from the Druid spell vendor Tiver Banes in Port Azure.
    /// </summary>
    public static class DruidSpellsPatches
    {
        /// <summary>
        /// Patch SpellDB.Start() to inject custom spells after the database loads.
        /// </summary>
        [HarmonyPatch(typeof(SpellDB), "Start")]
        public class SpellDB_Start_Patch
        {
            private static void Postfix(SpellDB __instance)
            {
                Debug.Log("DruidSpellsPatches: SpellDB.Start postfix - injecting custom spells...");

                // Initialize the spell registry (creates ScriptableObjects)
                SpellRegistry.Initialize();

                // Get our custom spells
                var customSpells = SpellRegistry.GetCreatedSpells();
                if (customSpells.Count == 0)
                {
                    Debug.Log("DruidSpellsPatches: No custom spells to inject.");
                    return;
                }

                // Expand the SpellDatabase array to include our custom spells
                var originalSpells = __instance.SpellDatabase;
                var newSpellArray = new Spell[originalSpells.Length + customSpells.Count];

                // Copy original spells
                for (int i = 0; i < originalSpells.Length; i++)
                {
                    newSpellArray[i] = originalSpells[i];
                }

                // Add custom spells
                for (int i = 0; i < customSpells.Count; i++)
                {
                    newSpellArray[originalSpells.Length + i] = customSpells[i];
                    Debug.Log($"DruidSpellsPatches: Added spell '{customSpells[i].SpellName}' to SpellDB");
                }

                // Replace the database array
                __instance.SpellDatabase = newSpellArray;

                Debug.Log($"DruidSpellsPatches: SpellDB now contains {newSpellArray.Length} spells " +
                         $"({originalSpells.Length} original + {customSpells.Count} custom)");
            }
        }
    }

    /// <summary>
    /// Cleans up old spell references from player and SimPlayer spellbooks.
    /// Handles migration from old druidspells_* IDs to new spiritofthewoof_* IDs.
    /// </summary>
    public static class SpellbookCleanupPatches
    {
        // Map of spell names to look for duplicates (these are our SoW spells)
        private static readonly string[] OurSpellNames = new string[]
        {
            "Lesser Spirit of the Wolf",
            "Spirit of the Wolf",
            "Spirit of the Greater Wolf",
            "Spirit of the Elder Wolf"
        };

        /// <summary>
        /// Patch PlayerControl.Start to clean up player's known spells after load
        /// and auto-learn SoW spells if enabled.
        /// </summary>
        [HarmonyPatch(typeof(PlayerControl), "Start")]
        public class PlayerControl_Start_Patch
        {
            private static void Postfix(PlayerControl __instance)
            {
                var castSpell = __instance.GetComponent<CastSpell>();
                if (castSpell == null || castSpell.KnownSpells == null)
                    return;

                // First, clean up any old/duplicate spell entries
                CleanupKnownSpells(castSpell.KnownSpells, "Player");

                // Then, auto-learn spells if enabled
                if (Plugin.AutoLearnSpells?.Value == true)
                {
                    AutoLearnSpells(castSpell.KnownSpells);
                }
            }
        }

        /// <summary>
        /// Auto-learns all SoW spells that the player doesn't already know.
        /// </summary>
        private static void AutoLearnSpells(System.Collections.Generic.List<Spell> knownSpells)
        {
            var customSpells = SpellRegistry.GetCreatedSpells();
            if (customSpells.Count == 0)
                return;

            int learnedCount = 0;
            foreach (var spell in customSpells)
            {
                // Check if spell is already known (by name to handle version changes)
                bool alreadyKnown = false;
                foreach (var knownSpell in knownSpells)
                {
                    if (knownSpell != null && knownSpell.SpellName == spell.SpellName)
                    {
                        alreadyKnown = true;
                        break;
                    }
                }

                if (!alreadyKnown)
                {
                    knownSpells.Add(spell);
                    learnedCount++;
                    Debug.Log($"SpiritOfTheWoof: Auto-learned spell '{spell.SpellName}'");
                }
            }

            if (learnedCount > 0)
            {
                Debug.Log($"SpiritOfTheWoof: Auto-learned {learnedCount} new spells");
            }
        }

        /// <summary>
        /// Patch SimPlayer.Start to clean up SimPlayer's known spells.
        /// </summary>
        [HarmonyPatch(typeof(SimPlayer), "Start")]
        public class SimPlayer_Start_Patch
        {
            private static void Postfix(SimPlayer __instance)
            {
                var castSpell = __instance.GetComponent<CastSpell>();
                if (castSpell == null || castSpell.KnownSpells == null)
                    return;

                string simName = __instance.GetComponent<NPC>()?.NPCName ?? __instance.transform.name;
                CleanupKnownSpells(castSpell.KnownSpells, simName);
            }
        }

        /// <summary>
        /// Cleans up a KnownSpells list by removing old/duplicate SoW spell entries
        /// and replacing them with the current versions from SpellRegistry.
        /// </summary>
        private static void CleanupKnownSpells(System.Collections.Generic.List<Spell> knownSpells, string ownerName)
        {
            if (knownSpells == null || knownSpells.Count == 0)
                return;

            // Get our current spell versions from the registry
            var ourSpells = SpellRegistry.GetCreatedSpells();
            if (ourSpells == null || ourSpells.Count == 0)
                return;

            // Build a lookup of our spell names to our current spell objects
            var spellNameToCurrentSpell = new System.Collections.Generic.Dictionary<string, Spell>();
            foreach (var spell in ourSpells)
            {
                if (spell != null && !string.IsNullOrEmpty(spell.SpellName))
                {
                    spellNameToCurrentSpell[spell.SpellName] = spell;
                }
            }

            // Find all spells in KnownSpells that match our spell names
            var spellsToRemove = new System.Collections.Generic.List<Spell>();
            var spellNamesToReAdd = new System.Collections.Generic.HashSet<string>();

            foreach (var spell in knownSpells)
            {
                if (spell == null)
                    continue;

                // Check if this spell matches one of our spell names
                if (spellNameToCurrentSpell.ContainsKey(spell.SpellName))
                {
                    // Check if it's our current version (by checking ID prefix)
                    string spellId = GetSpellId(spell);
                    if (spellId == null || !spellId.StartsWith("spiritofthewoof_"))
                    {
                        // Old version - mark for removal and re-add
                        spellsToRemove.Add(spell);
                        spellNamesToReAdd.Add(spell.SpellName);
                        Debug.Log($"[SpiritOfTheWoof] {ownerName}: Marking old spell for removal: '{spell.SpellName}' (ID: {spellId ?? "null"})");
                    }
                }
            }

            // Also check for duplicates of the same spell name
            var seenNames = new System.Collections.Generic.Dictionary<string, Spell>();
            foreach (var spell in knownSpells)
            {
                if (spell == null || !spellNameToCurrentSpell.ContainsKey(spell.SpellName))
                    continue;

                if (seenNames.ContainsKey(spell.SpellName))
                {
                    // Duplicate - keep the one with spiritofthewoof_ prefix, remove the other
                    string currentId = GetSpellId(spell);
                    string seenId = GetSpellId(seenNames[spell.SpellName]);

                    if (currentId != null && currentId.StartsWith("spiritofthewoof_"))
                    {
                        // Current one is correct, remove the previously seen one
                        if (!spellsToRemove.Contains(seenNames[spell.SpellName]))
                        {
                            spellsToRemove.Add(seenNames[spell.SpellName]);
                            Debug.Log($"[SpiritOfTheWoof] {ownerName}: Removing duplicate: '{spell.SpellName}' (ID: {seenId ?? "null"})");
                        }
                        seenNames[spell.SpellName] = spell;
                    }
                    else
                    {
                        // Current one is old/wrong, remove it
                        if (!spellsToRemove.Contains(spell))
                        {
                            spellsToRemove.Add(spell);
                            Debug.Log($"[SpiritOfTheWoof] {ownerName}: Removing duplicate: '{spell.SpellName}' (ID: {currentId ?? "null"})");
                        }
                    }
                }
                else
                {
                    seenNames[spell.SpellName] = spell;
                }
            }

            // Remove old spells
            foreach (var spell in spellsToRemove)
            {
                knownSpells.Remove(spell);
            }

            // Re-add with current versions
            foreach (var spellName in spellNamesToReAdd)
            {
                if (spellNameToCurrentSpell.TryGetValue(spellName, out var currentSpell))
                {
                    if (!knownSpells.Contains(currentSpell))
                    {
                        knownSpells.Add(currentSpell);
                        Debug.Log($"[SpiritOfTheWoof] {ownerName}: Re-added spell with correct version: '{spellName}'");
                    }
                }
            }

            if (spellsToRemove.Count > 0)
            {
                Debug.Log($"[SpiritOfTheWoof] {ownerName}: Cleaned up {spellsToRemove.Count} old spell references, re-added {spellNamesToReAdd.Count} with current versions");
            }
        }

        /// <summary>
        /// Gets the Id of a spell using reflection (Id is in base class).
        /// </summary>
        private static string GetSpellId(Spell spell)
        {
            if (spell == null)
                return null;

            // Try to get Id via reflection
            var idField = typeof(Spell).BaseType?.GetField("Id", System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Instance);
            if (idField != null)
            {
                return idField.GetValue(spell) as string;
            }

            // Fallback to Unity name
            return spell.name;
        }
    }
}


using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using HarmonyLib;
using UnityEngine;

namespace SpiritOfTheWoof
{
    [BepInPlugin("the-xorcist.spiritofthewoof", "Spirit Of The Woof", "1.0.0")]
    public class Plugin : BaseUnityPlugin
    {
        public static Plugin Instance { get; private set; }

        /// <summary>
        /// Expose logger for other classes to use.
        /// </summary>
        public new ManualLogSource Logger => base.Logger;

        // =======================================================================
        // SimPlayer SoW Request Behavior
        // =======================================================================

        /// <summary>
        /// Enable SimPlayers to request Spirit of the Wolf buffs via whisper/shout.
        /// </summary>
        public static ConfigEntry<bool> EnableSoWRequests;

        /// <summary>
        /// Base chance per tick (6 seconds) for a SimPlayer to request SoW via whisper.
        /// Modified by zone size, dungeon status, and group status.
        /// </summary>
        public static ConfigEntry<float> SoWWhisperBaseChance;

        /// <summary>
        /// Base chance per tick for a SimPlayer to shout for SoW in zone chat.
        /// Modified by zone size, dungeon status, and group status.
        /// </summary>
        public static ConfigEntry<float> SoWShoutBaseChance;

        private void Awake()
        {
            Instance = this;
            Logger.LogInfo("SpiritOfTheWoof: Initializing...");

            // Bind config entries - SimPlayer SoW Requests
            EnableSoWRequests = Config.Bind(
                "SimPlayer SoW Requests",
                "EnableSoWRequests",
                true,
                "Enable SimPlayers to request Spirit of the Wolf buffs via whisper and shout.");

            SoWWhisperBaseChance = Config.Bind(
                "SimPlayer SoW Requests",
                "WhisperBaseChance",
                0.5f,
                new ConfigDescription(
                    "Base chance (%) per tick for a lone SimPlayer to whisper you for SoW. " +
                    "Reduced in dungeons and when grouped. Set to 0 to disable whispers.",
                    new AcceptableValueRange<float>(0f, 10f)));

            SoWShoutBaseChance = Config.Bind(
                "SimPlayer SoW Requests",
                "ShoutBaseChance",
                0.2f,
                new ConfigDescription(
                    "Base chance (%) per tick for a lone SimPlayer to shout for SoW in zone chat. " +
                    "Reduced in dungeons and when grouped. Set to 0 to disable shouts.",
                    new AcceptableValueRange<float>(0f, 10f)));

            // Register all spell definitions (before SpellDB.Start runs)
            SpiritOfTheWoofMod.RegisterAllSpells();

            // Apply Harmony patches:
            // - SpellDB_Start_Patch: injects custom spells into SpellDB
            // - SpellMessageFixer: fixes "did not take hold" message display
            // - BackwardSpeedCapFixer: applies movement buff to backward speed cap
            Harmony harmony = new Harmony("the-xorcist.spiritofthewoof");
            harmony.PatchAll();

            Logger.LogInfo("SpiritOfTheWoof: Plugin loaded.");
        }

        private void Update()
        {
            // F9 = Debug dump of status effects and movement speed
            if (Input.GetKeyDown(KeyCode.F9))
            {
                DumpStatusEffects();
            }
        }

        private void DumpStatusEffects()
        {
            if (GameData.PlayerStats == null)
            {
                Logger.LogInfo("[SpiritOfTheWoof Debug] PlayerStats is null");
                return;
            }

            var stats = GameData.PlayerStats;
            Logger.LogInfo($"[SpiritOfTheWoof Debug] === Status Effect Dump ===");
            Logger.LogInfo($"[SpiritOfTheWoof Debug] RunSpeed (base): {stats.RunSpeed}");
            Logger.LogInfo($"[SpiritOfTheWoof Debug] actualRunSpeed: {stats.actualRunSpeed}");

            var statusEffects = stats.StatusEffects;
            int count = 0;
            float totalMovementSpeed = 0f;

            for (int i = 0; i < statusEffects.Length; i++)
            {
                if (statusEffects[i] != null && statusEffects[i].Effect != null)
                {
                    var effect = statusEffects[i].Effect;
                    count++;
                    Logger.LogInfo($"[SpiritOfTheWoof Debug] Slot {i}: {effect.SpellName} (Line: {effect.Line}, MovementSpeed: {effect.MovementSpeed}, Duration: {statusEffects[i].Duration})");
                    totalMovementSpeed += effect.MovementSpeed;
                }
            }

            Logger.LogInfo($"[SpiritOfTheWoof Debug] Total status effects: {count}");
            Logger.LogInfo($"[SpiritOfTheWoof Debug] Total MovementSpeed from effects: {totalMovementSpeed}");
            Logger.LogInfo($"[SpiritOfTheWoof Debug] Expected actualRunSpeed: {stats.RunSpeed + totalMovementSpeed}");
            Logger.LogInfo($"[SpiritOfTheWoof Debug] === End Dump ===");
        }
    }
}


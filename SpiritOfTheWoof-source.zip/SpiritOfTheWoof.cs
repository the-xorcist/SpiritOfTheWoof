using HarmonyLib;
using UnityEngine;

namespace SpiritOfTheWoof
{
    /// <summary>
    /// Main mod class - registers spell definitions.
    /// To add a new spell, add a new RegisterSpell call in RegisterAllSpells().
    /// </summary>
    public static class SpiritOfTheWoofMod
    {
        /// <summary>
        /// Register all custom Druid spells here.
        /// Called at plugin startup before databases are loaded.
        /// </summary>
        public static void RegisterAllSpells()
        {
            // Lesser Spirit of the Wolf - Entry level movement speed buff
            SpellRegistry.RegisterSpell(new SpellRegistry.SpellDefinition
            {
                Id = "druidspells_lesser_spirit_of_the_wolf",
                SpellName = "Lesser Spirit of the Wolf",
                Description = "Calls upon a lesser wolf spirit to increase movement speed.",
                IconFileName = "sow_64x64.png",
                Type = Spell.SpellType.Beneficial,
                Line = Spell.SpellLine.Global_Move,
                RequiredLevel = 5,
                ManaCost = 50,
                CastTime = 360f, // 6 seconds (60 ticks = 1 second)
                DurationTicks = 150, // 15 minutes (1 tick = 6 seconds)
                MovementSpeed = 1.5f,
                SelfOnly = false,
                SpellRange = 100f,
                ChargeFXIndex = 7,
                ResolveFXIndex = 7,
                StatusMessagePlayer = "You feel a lesser wolf spirit guiding your steps.",
                StatusMessageNPC = " feels a lesser wolf spirit.",
                GetClass = () => GameData.ClassDB?.Druid
            });

            // Spirit of the Wolf - Standard movement speed buff
            SpellRegistry.RegisterSpell(new SpellRegistry.SpellDefinition
            {
                Id = "druidspells_spirit_of_the_wolf",
                SpellName = "Spirit of the Wolf",
                Description = "Calls upon the spirit of the wolf to increase movement speed.",
                IconFileName = "sow_64x64.png",
                Type = Spell.SpellType.Beneficial,
                Line = Spell.SpellLine.Global_Move,
                RequiredLevel = 15,
                ManaCost = 100,
                CastTime = 600f, // 10 seconds (60 ticks = 1 second)
                DurationTicks = 300, // 30 minutes (1 tick = 6 seconds)
                MovementSpeed = 2.5f,
                SelfOnly = false,
                SpellRange = 100f,
                ChargeFXIndex = 7,
                ResolveFXIndex = 7,
                StatusMessagePlayer = "You feel the spirit of the wolf coursing through you.",
                StatusMessageNPC = " feels the spirit of the wolf.",
                GetClass = () => GameData.ClassDB?.Druid
            });

            // Spirit of the Greater Wolf - Enhanced movement speed buff
            SpellRegistry.RegisterSpell(new SpellRegistry.SpellDefinition
            {
                Id = "druidspells_spirit_of_the_greater_wolf",
                SpellName = "Spirit of the Greater Wolf",
                Description = "Calls upon a greater wolf spirit to greatly increase movement speed.",
                IconFileName = "sow_64x64.png",
                Type = Spell.SpellType.Beneficial,
                Line = Spell.SpellLine.Global_Move,
                RequiredLevel = 25,
                ManaCost = 150,
                CastTime = 600f, // 10 seconds (60 ticks = 1 second)
                DurationTicks = 450, // 45 minutes (1 tick = 6 seconds)
                MovementSpeed = 3.5f,
                SelfOnly = false,
                SpellRange = 100f,
                ChargeFXIndex = 7,
                ResolveFXIndex = 7,
                StatusMessagePlayer = "You feel a greater wolf spirit empowering your stride.",
                StatusMessageNPC = " feels a greater wolf spirit.",
                GetClass = () => GameData.ClassDB?.Druid
            });

            // Spirit of the Elder Wolf - Ultimate movement speed buff
            SpellRegistry.RegisterSpell(new SpellRegistry.SpellDefinition
            {
                Id = "druidspells_spirit_of_the_elder_wolf",
                SpellName = "Spirit of the Elder Wolf",
                Description = "Calls upon an ancient elder wolf spirit for maximum movement speed.",
                IconFileName = "sow_64x64.png",
                Type = Spell.SpellType.Beneficial,
                Line = Spell.SpellLine.Global_Move,
                RequiredLevel = 35,
                ManaCost = 200,
                CastTime = 300f, // 5 seconds (60 ticks = 1 second)
                DurationTicks = 600, // 60 minutes (1 tick = 6 seconds)
                MovementSpeed = 5.0f,
                SelfOnly = false,
                SpellRange = 100f,
                ChargeFXIndex = 7,
                ResolveFXIndex = 7,
                StatusMessagePlayer = "You feel an elder wolf spirit infusing your very being.",
                StatusMessageNPC = " feels an elder wolf spirit.",
                GetClass = () => GameData.ClassDB?.Druid
            });

            Debug.Log("SpiritOfTheWoofMod: All spell definitions registered.");
        }
    }

    /// <summary>
    /// Harmony patches to inject custom spells into the game's SpellDB.
    /// Spells are acquired from the Druid spell vendor Tiver Banes in Port Azure.
    /// </summary>
    public static class DruidSpellsPatches
    {
        /// <summary>
        /// Patch SpellDB.Start() to inject custom spells after the database loads.
        /// </summary>
        [HarmonyPatch(typeof(SpellDB), "Start")]
        public class SpellDB_Start_Patch
        {
            private static void Postfix(SpellDB __instance)
            {
                Debug.Log("DruidSpellsPatches: SpellDB.Start postfix - injecting custom spells...");

                // Initialize the spell registry (creates ScriptableObjects)
                SpellRegistry.Initialize();

                // Get our custom spells
                var customSpells = SpellRegistry.GetCreatedSpells();
                if (customSpells.Count == 0)
                {
                    Debug.Log("DruidSpellsPatches: No custom spells to inject.");
                    return;
                }

                // Expand the SpellDatabase array to include our custom spells
                var originalSpells = __instance.SpellDatabase;
                var newSpellArray = new Spell[originalSpells.Length + customSpells.Count];

                // Copy original spells
                for (int i = 0; i < originalSpells.Length; i++)
                {
                    newSpellArray[i] = originalSpells[i];
                }

                // Add custom spells
                for (int i = 0; i < customSpells.Count; i++)
                {
                    newSpellArray[originalSpells.Length + i] = customSpells[i];
                    Debug.Log($"DruidSpellsPatches: Added spell '{customSpells[i].SpellName}' to SpellDB");
                }

                // Replace the database array
                __instance.SpellDatabase = newSpellArray;

                Debug.Log($"DruidSpellsPatches: SpellDB now contains {newSpellArray.Length} spells " +
                         $"({originalSpells.Length} original + {customSpells.Count} custom)");
            }
        }
    }
}

